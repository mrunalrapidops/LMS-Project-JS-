module.exports={
    JWT_SECRET: 'codeauthentication'
}