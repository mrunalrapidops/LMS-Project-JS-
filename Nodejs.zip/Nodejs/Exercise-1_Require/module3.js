    'use strict';
    function add(a,b){
     console.log(`${a} + ${b} = ${a+b}`);
    }
    function sub(a,b){
     console.log(`${a} - ${b} = ${a-b}`);
    }
    module.exports={
     add:add,
     sub:sub
    };
