    var prefix='Mr';
    module.exports=function(name){
     console.log(`Hello ${prefix} ${name}`);
    };
