console.log("HI");
global.console.log("global.HI");






